package in.wptrafficanalyzer.opendialogfragment;

public class Country {
	static String[] name = new String[] {
			"India",
            "Pakistan",
            "Sri Lanka",
            "China",
            "Bangladesh",
            "Nepal",
            "Afghanistan",
            "North Korea",
            "South Korea",
            "Japan"	
	};
	
	static String[] tz = new String[] {
		"GMT+5:30",
		"GMT+5:00",
		"GMT+5:30",
		"GMT+8:00",
		"GMT+6:00",
		"GMT+5:45",
		"GMT+4:30",
		"GMT+9:00",
		"GMT+9:00",
		"GMT+9:00"
		
	};

}
