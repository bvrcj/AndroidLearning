package in.wptrafficanalyzer.opendialogfragment;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;

public class MainActivity extends ListActivity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        /** Array adapter to store a list of countries, which acts as a datasource to the list */
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, Country.name);
        
        /** Setting the data source to the list view */
        setListAdapter(adapter);
        
        
        /** An Item click listener , will be invoked when an item in the list view is clicked */
        OnItemClickListener listener = new OnItemClickListener() {
        	@Override
        	public void onItemClick(AdapterView<?> arg0, View arg1, int position, long id) {
        		
        		/** Instantiating TimeDailogFragment, which is a DialogFragment object */
        		TimeDialogFragment tFragment = new TimeDialogFragment();
        		
        		/** Creating a bundle object to store the position of the selected country */
        		Bundle b = new Bundle();
        		
        		/** Storing the position in the bundle object */
        		b.putInt("position", position);
        		
        		/** Setting the bundle object as an argument to the DialogFragment object */
        		tFragment.setArguments(b);
        		
        		/** Getting FragmentManager object */
        		FragmentManager fragmentManager = getFragmentManager();
        		
        		/** Starting a FragmentTransaction */
        		FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        		
        		/** Getting the previously created fragment object from the fragment manager */
        		TimeDialogFragment tPrev =  ( TimeDialogFragment ) fragmentManager.findFragmentByTag("time_dialog");
        		
        		/** If the previously created fragment object still exists, then that has to be removed */
        		if(tPrev!=null)
        			fragmentTransaction.remove(tPrev);
        		
        		/** Opening the fragment object */
        		tFragment.show(fragmentTransaction, "time_dialog");        		        		
        	}        	
		};
		
		/** Setting an item click event handler for the list view */
		getListView().setOnItemClickListener(listener);
        
    }
}