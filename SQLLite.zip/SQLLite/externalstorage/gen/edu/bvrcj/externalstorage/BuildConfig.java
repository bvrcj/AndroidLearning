/** Automatically generated file. DO NOT MODIFY */
package edu.bvrcj.externalstorage;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}